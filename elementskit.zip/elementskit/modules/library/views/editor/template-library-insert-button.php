<?php include('template-library-live-button.php'); ?>

<button class="elementor-template-library-template-action elementskit-template-library-template-insert elementor-button elementor-button-success">
	<i class="eicon-file-download"></i><span class="elementor-button-title"><?php
		esc_html_e( 'Insert', 'elementskit' );
	?></span>
</button>