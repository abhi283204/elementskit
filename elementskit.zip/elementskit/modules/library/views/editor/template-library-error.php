<?php
/**
 * templates loader view
 */
?>
<div class="elementor-library-error">
	<div class="elementor-library-error-message"><?php
		esc_html_e( 'Template couldn\'t be loaded. Please activate you license key before.', 'elementskit' );
	?></div>
	<div class="elementor-library-error-link"><?php

	?></div>
</div>